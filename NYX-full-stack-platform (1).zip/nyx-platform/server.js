require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const multer = require("multer");
const pdfParse = require("pdf-parse");
const mammoth = require("mammoth");
const OpenAI = require("openai");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve("./data");
const UPLOAD_DIR = path.resolve("./uploads");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(process.env.DATABASE_PATH || path.join(DATA_DIR, "nyx.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  premium_until TEXT,
  razorpay_subscription_id TEXT
);
CREATE TABLE IF NOT EXISTS chats (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL DEFAULT 'New chat',
  messages_json TEXT NOT NULL DEFAULT '[]',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS payment_events (
  event_id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
// Razorpay webhook requires raw request bytes; register it before express.json().
app.post("/api/billing/webhook", express.raw({ type: "application/json" }), handleRazorpayWebhook);
app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ extended: false }));
app.use("/api", rateLimit({ windowMs: 60_000, limit: 100, standardHeaders: true, legacyHeaders: false }));
app.use(session({
  name: "nyx.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret-now",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 8 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = [
      "text/plain", "text/markdown", "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "image/png", "image/jpeg", "image/webp"
    ];
    cb(allowed.includes(file.mimetype) ? null : new Error("Unsupported file type. Upload TXT, MD, PDF, DOCX, PNG, JPG, or WEBP."), allowed.includes(file.mimetype));
  }
});

function openAI() {
  if (!process.env.OPENAI_API_KEY) throw new Error("AI is not configured. Add OPENAI_API_KEY to the server .env file.");
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}
function isOwner(user) {
  return !!(user && process.env.OWNER_EMAIL && user.email.toLowerCase() === process.env.OWNER_EMAIL.trim().toLowerCase());
}
function isPremium(user) {
  return isOwner(user) || !!(user && user.premium_until && new Date(user.premium_until) > new Date());
}
function publicUser(user) {
  return {
    id: user.id,
    email: user.email,
    premium: isPremium(user),
    owner: isOwner(user),
    premiumUntil: isOwner(user) ? "Owner access" : (user.premium_until || null)
  };
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in first." });
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId);
  if (!user) return res.status(401).json({ error: "Session expired. Please sign in again." });
  req.user = user;
  next();
}
function requirePremium(req, res, next) {
  if (!isPremium(req.user)) return res.status(402).json({ error: "This feature is available only with NYX Premium (₹250/month)." });
  next();
}
function safeChatTitle(text) {
  return String(text || "New chat").replace(/\s+/g, " ").slice(0, 70) || "New chat";
}
function safeEqual(a, b) {
  if (!a || !b) return false;
  const aa = Buffer.from(String(a)), bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

app.get("/api/health", (_req, res) => res.json({
  ok: true, app: "NYX", creator: "Shiv Vipul Choksi",
  aiConfigured: !!process.env.OPENAI_API_KEY,
  webSearchConfigured: !!process.env.TAVILY_API_KEY,
  paymentsConfigured: !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET && process.env.RAZORPAY_PLAN_ID),
  videoConfigured: !!(process.env.OPENAI_API_KEY && process.env.OPENAI_VIDEO_MODEL)
}));
app.get("/api/me", (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId);
  res.json({ user: user ? publicUser(user) : null });
});

app.post("/api/auth/register", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 10) return res.status(400).json({ error: "Use a password with at least 10 characters." });
  if (password.length > 200) return res.status(400).json({ error: "Password is too long." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").run(email, hash);
    req.session.userId = Number(info.lastInsertRowid);
    const user = db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
    res.json({ user: publicUser(user) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "An account with that email already exists." });
    console.error(e);
    res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/auth/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});
app.post("/api/auth/logout", (req, res) => req.session.destroy(() => {
  res.clearCookie("nyx.sid");
  res.json({ ok: true });
}));

app.get("/api/chats", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT id,title,updated_at FROM chats WHERE user_id=? ORDER BY updated_at DESC LIMIT 100").all(req.user.id);
  res.json({ chats: rows });
});
app.get("/api/chats/:id", requireAuth, (req, res) => {
  const row = db.prepare("SELECT id,title,messages_json,updated_at FROM chats WHERE id=? AND user_id=?").get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: "Chat not found." });
  res.json({ chat: { id: row.id, title: row.title, messages: JSON.parse(row.messages_json), updatedAt: row.updated_at } });
});
app.post("/api/chats", requireAuth, (req, res) => {
  const id = crypto.randomUUID();
  const title = safeChatTitle(req.body.title || "New chat");
  db.prepare("INSERT INTO chats(id,user_id,title,messages_json) VALUES(?,?,?,'[]')").run(id, req.user.id, title);
  res.json({ id, title, messages: [] });
});
app.put("/api/chats/:id", requireAuth, (req, res) => {
  const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-100) : null;
  if (!messages) return res.status(400).json({ error: "Messages must be an array." });
  const safeMessages = messages.map(m => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content || "").slice(0, 30000)
  }));
  const title = safeChatTitle(req.body.title || safeMessages.find(m => m.role === "user")?.content || "New chat");
  const result = db.prepare("UPDATE chats SET title=?,messages_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?")
    .run(title, JSON.stringify(safeMessages), req.params.id, req.user.id);
  if (!result.changes) return res.status(404).json({ error: "Chat not found." });
  res.json({ ok: true });
});
app.delete("/api/chats/:id", requireAuth, (req, res) => {
  const result = db.prepare("DELETE FROM chats WHERE id=? AND user_id=?").run(req.params.id, req.user.id);
  if (!result.changes) return res.status(404).json({ error: "Chat not found." });
  res.json({ ok: true });
});

async function tavilySearch(query) {
  if (!process.env.TAVILY_API_KEY) throw new Error("Web search is not configured. Add TAVILY_API_KEY to .env.");
  const response = await fetch("https://api.tavily.com/search", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ api_key: process.env.TAVILY_API_KEY, query, search_depth: "advanced", max_results: 5, include_answer: true })
  });
  if (!response.ok) throw new Error("Web search provider returned an error.");
  return response.json();
}
app.post("/api/search", requireAuth, async (req, res) => {
  try {
    const query = String(req.body.query || "").trim().slice(0, 500);
    if (!query) return res.status(400).json({ error: "Enter a search query." });
    const data = await tavilySearch(query);
    res.json({ answer: data.answer || "", results: (data.results || []).map(r => ({ title: r.title, url: r.url, content: r.content })) });
  } catch (e) { res.status(503).json({ error: e.message || "Web search failed." }); }
});

app.post("/api/chat", requireAuth, async (req, res) => {
  try {
    const history = Array.isArray(req.body.messages) ? req.body.messages.slice(-18) : [];
    const userText = String(req.body.message || "").trim().slice(0, 12000);
    if (!userText) return res.status(400).json({ error: "Write a message first." });
    let webContext = "";
    if (req.body.webSearch) {
      try {
        const search = await tavilySearch(userText);
        webContext = "\nWEB SEARCH RESULTS (cite these URLs; do not invent sources):\n" +
          (search.answer ? `Summary: ${search.answer}\n` : "") +
          (search.results || []).map((r, i) => `${i + 1}. ${r.title}\n${r.content}\nURL: ${r.url}`).join("\n\n");
      } catch (e) {
        webContext = `\nWeb search was requested but failed: ${e.message}. Be transparent that live search was unavailable.`;
      }
    }
    const system = `You are NYX, an AI assistant created by Shiv Vipul Choksi. Be friendly, accurate, and transparent about uncertainty. If asked who created you, say Shiv Vipul Choksi. If asked where you are from, explain you are software with no physical hometown. If asked "How are you?", answer "I'm fine, thanks for asking! How are you doing?" Understand the user's tone and respond empathetically without claiming to have human feelings. Help with general questions, education, writing, coding, planning, and analysis. Never claim to have performed real-world actions or invent sources. When web results are provided, cite exact URLs in Markdown. If a request requires money, account access, or a real-world human action, explain what you can help prepare but do not claim to complete it. ${webContext}`;
    const client = openAI();
    const apiMessages = [{ role: "system", content: system }];
    for (const m of history) {
      if (!m || !["user", "assistant"].includes(m.role)) continue;
      apiMessages.push({ role: m.role, content: String(m.content || "").slice(0, 12000) });
    }
    if (req.body.imageData && /^data:image\/(png|jpeg|webp);base64,/.test(req.body.imageData)) {
      apiMessages.push({ role: "user", content: [
        { type: "text", text: userText },
        { type: "image_url", image_url: { url: req.body.imageData } }
      ] });
    } else {
      apiMessages.push({ role: "user", content: userText });
    }
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_CHAT_MODEL || "gpt-4o-mini",
      messages: apiMessages, temperature: 0.7, max_tokens: 1800
    });
    res.json({ answer: completion.choices?.[0]?.message?.content || "I couldn't produce an answer. Please try again." });
  } catch (e) {
    console.error("chat error:", e.message);
    res.status(503).json({ error: e.message || "AI request failed." });
  }
});

app.post("/api/files", requireAuth, upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choose a file." });
  const filePath = req.file.path;
  try {
    const type = req.file.mimetype;
    if (type.startsWith("image/")) {
      const base64 = fs.readFileSync(filePath).toString("base64");
      return res.json({ name: req.file.originalname, kind: "image", imageData: `data:${type};base64,${base64}`, text: "Image attached. Ask NYX to describe or analyze it." });
    }
    let text = "";
    if (type === "text/plain" || type === "text/markdown") text = fs.readFileSync(filePath, "utf8");
    else if (type === "application/pdf") text = (await pdfParse(fs.readFileSync(filePath))).text;
    else if (type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") text = (await mammoth.extractRawText({ path: filePath })).value;
    res.json({ name: req.file.originalname, kind: "document", text: String(text).slice(0, 30000) });
  } catch {
    res.status(400).json({ error: "Could not read this file. Try a text-based PDF or DOCX." });
  } finally {
    fs.promises.unlink(filePath).catch(() => {});
  }
});

app.post("/api/images", requireAuth, requirePremium, async (req, res) => {
  try {
    const prompt = String(req.body.prompt || "").trim().slice(0, 2000);
    if (!prompt) return res.status(400).json({ error: "Describe the image you want." });
    const result = await openAI().images.generate({ model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1", prompt, size: "1024x1024" });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error("Image provider returned no image.");
    res.json({ imageData: `data:image/png;base64,${b64}` });
  } catch (e) {
    console.error("image error:", e.message);
    res.status(503).json({ error: e.message || "Image generation failed." });
  }
});

// Premium-only video generation. Uses OpenAI's video API; provider/model access may not be enabled for every account.
app.post("/api/videos", requireAuth, requirePremium, async (req, res) => {
  const prompt = String(req.body.prompt || "").trim().slice(0, 1800);
  if (!prompt) return res.status(400).json({ error: "Describe the video you want." });
  if (!process.env.OPENAI_API_KEY || !process.env.OPENAI_VIDEO_MODEL) {
    return res.status(503).json({ error: "Video generation is not configured. Add an eligible video API key/model to the server .env file." });
  }
  try {
    const form = new FormData();
    form.append("model", process.env.OPENAI_VIDEO_MODEL);
    form.append("prompt", prompt);
    form.append("seconds", String(Math.min(12, Math.max(4, Number(req.body.seconds || 8)))));
    form.append("size", "1280x720");
    const createResponse = await fetch("https://api.openai.com/v1/videos", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: form
    });
    const createData = await createResponse.json();
    if (!createResponse.ok) {
      console.error("video provider error:", createData);
      return res.status(503).json({ error: createData.error?.message || "Video provider rejected the request. Confirm your account has video API access." });
    }
    res.status(202).json({ videoId: createData.id, status: createData.status || "queued", message: "Video generation started. Check status to see when it is ready." });
  } catch (e) {
    console.error("video error:", e.message);
    res.status(503).json({ error: "Could not start video generation. Check video API access and server logs." });
  }
});
app.get("/api/videos/:id", requireAuth, requirePremium, async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Video provider is not configured." });
  if (!/^[a-zA-Z0-9_-]{3,200}$/.test(req.params.id)) return res.status(400).json({ error: "Invalid video ID." });
  try {
    const r = await fetch(`https://api.openai.com/v1/videos/${encodeURIComponent(req.params.id)}`, {
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }
    });
    const data = await r.json();
    if (!r.ok) return res.status(503).json({ error: data.error?.message || "Could not check video status." });
    let videoUrl = null;
    if (data.status === "completed") videoUrl = `/api/videos/${encodeURIComponent(req.params.id)}/content`;
    res.json({ id: data.id, status: data.status, progress: data.progress ?? null, videoUrl, error: data.error || null });
  } catch {
    res.status(503).json({ error: "Could not check video status." });
  }
});
app.get("/api/videos/:id/content", requireAuth, requirePremium, async (req, res) => {
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Video provider is not configured." });
  if (!/^[a-zA-Z0-9_-]{3,200}$/.test(req.params.id)) return res.status(400).json({ error: "Invalid video ID." });
  try {
    const r = await fetch(`https://api.openai.com/v1/videos/${encodeURIComponent(req.params.id)}/content`, {
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }
    });
    if (!r.ok) {
      const msg = await r.text();
      return res.status(503).json({ error: "Video is not ready or could not be downloaded: " + msg.slice(0, 300) });
    }
    res.setHeader("Content-Type", r.headers.get("content-type") || "video/mp4");
    res.setHeader("Content-Disposition", 'inline; filename="nyx-video.mp4"');
    const bytes = Buffer.from(await r.arrayBuffer());
    res.send(bytes);
  } catch {
    res.status(503).json({ error: "Could not download the generated video." });
  }
});

// Razorpay subscription checkout. Create a ₹250/month plan in the dashboard first.
app.post("/api/billing/create-subscription", requireAuth, async (req, res) => {
  try {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET || !process.env.RAZORPAY_PLAN_ID) {
      return res.status(503).json({ error: "Payments are not configured. Add Razorpay credentials and plan ID to .env." });
    }
    const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    const sub = await razorpay.subscriptions.create({
      plan_id: process.env.RAZORPAY_PLAN_ID, customer_notify: 1, quantity: 1, total_count: 120,
      notes: { nyx_user_id: String(req.user.id), product: "NYX Premium ₹250/month" }
    });
    db.prepare("UPDATE users SET razorpay_subscription_id=? WHERE id=?").run(sub.id, req.user.id);
    res.json({ subscriptionId: sub.id, keyId: process.env.RAZORPAY_KEY_ID });
  } catch (e) {
    console.error("subscription error:", e.message);
    res.status(503).json({ error: "Could not start subscription. Check Razorpay plan and server configuration." });
  }
});
app.post("/api/billing/verify", requireAuth, (req, res) => {
  const { razorpay_payment_id, razorpay_subscription_id, razorpay_signature } = req.body || {};
  if (!razorpay_payment_id || !razorpay_subscription_id || !razorpay_signature) return res.status(400).json({ error: "Missing payment verification fields." });
  if (razorpay_subscription_id !== req.user.razorpay_subscription_id) return res.status(400).json({ error: "Subscription does not match this account." });
  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET || "").update(`${razorpay_payment_id}|${razorpay_subscription_id}`).digest("hex");
  if (!safeEqual(expected, razorpay_signature)) return res.status(400).json({ error: "Payment signature verification failed." });
  res.json({ ok: true, message: "Checkout signature verified. Premium activates only when Razorpay confirms the subscription through a verified webhook." });
});
function handleRazorpayWebhook(req, res) {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return res.status(503).send("Webhook secret is not configured.");
  const signature = req.headers["x-razorpay-signature"];
  const expected = crypto.createHmac("sha256", secret).update(req.body).digest("hex");
  if (!safeEqual(expected, signature)) return res.status(400).send("Invalid webhook signature.");
  let event;
  try { event = JSON.parse(req.body.toString("utf8")); } catch { return res.status(400).send("Invalid JSON."); }
  const eventId = req.headers["x-razorpay-event-id"] || crypto.createHash("sha256").update(req.body).digest("hex");
  const insert = db.prepare("INSERT OR IGNORE INTO payment_events(event_id,event_type) VALUES(?,?)").run(eventId, event.event || "unknown");
  if (!insert.changes) return res.json({ ok: true, duplicate: true });
  const sub = event.payload?.subscription?.entity;
  if (sub?.id) {
    const user = db.prepare("SELECT id FROM users WHERE razorpay_subscription_id=?").get(sub.id);
    if (user) {
      if (["subscription.activated", "subscription.charged"].includes(event.event)) {
        const until = new Date(Date.now() + 32 * 24 * 60 * 60 * 1000).toISOString();
        db.prepare("UPDATE users SET premium_until=? WHERE id=?").run(until, user.id);
      } else if (["subscription.cancelled", "subscription.halted", "subscription.completed"].includes(event.event)) {
        db.prepare("UPDATE users SET premium_until=NULL WHERE id=?").run(user.id);
      }
    }
  }
  res.json({ ok: true });
}

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.message });
  res.status(400).json({ error: err.message || "Request failed." });
});
app.listen(PORT, () => console.log(`NYX by Shiv Vipul Choksi listening on ${PORT}`));
