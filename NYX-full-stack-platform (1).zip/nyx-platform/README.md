# NYX AI — full-stack starter

Created by **Shiv Vipul Choksi**.

This is a real full-stack starter, not a clone of ChatGPT/Gemini and not an unlimited-free AI service. It includes:
- Email/password accounts (bcrypt password hashes)
- Server-side AI chat integration
- Per-account chat history in SQLite
- Optional live web research via Tavily
- TXT, Markdown, text-based PDF, DOCX, PNG/JPG/WEBP uploads
- Premium-only image and video routes
- Razorpay subscription setup and webhook verification
- Owner Premium access based on `OWNER_EMAIL`

## Important before publishing
- You must supply valid provider credentials and pay any usage costs. Model/API access and video generation availability depend on the provider/account.
- Do not commit `.env`, API keys, passwords, SQLite data, or uploaded files.
- Set `OWNER_EMAIL` to the email you use to register; that account is granted owner Premium. This is an environment setting, not a frontend switch.
- Premium is not granted merely because checkout opens. The verified Razorpay webhook activates it.
- For production, configure a persistent disk for `data/` and a durable session store (the default Express MemoryStore is for testing only). Set `NODE_ENV=production` and use HTTPS.
- The included video integration uses OpenAI's `/v1/videos` API. It will return a clear error if your provider account does not have video API access or the model is unavailable.
- Razorpay subscriptions require an eligible Razorpay account and a plan created in the dashboard. If you're under 18, have a parent/guardian handle account setup and payment compliance.

## Run locally
1. Install Node.js 20 or newer.
2. Extract this ZIP and open a terminal in the `nyx-platform` folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set `SESSION_SECRET` to a long random value and set `OWNER_EMAIL` to your sign-in email.
6. Add `OPENAI_API_KEY` for chat and image tools.
7. Optional: add `TAVILY_API_KEY` for web search.
8. Run `npm start`.
9. Open `http://localhost:3000`.

## Set up the ₹250/month Razorpay plan
1. Create/activate your Razorpay account and use test mode first.
2. In Razorpay Dashboard, create a subscription plan for ₹250 with a monthly interval.
3. Copy its Plan ID to `RAZORPAY_PLAN_ID`.
4. Copy Key ID and Key Secret to `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`.
5. Add a webhook pointing to `https://YOUR-DOMAIN/api/billing/webhook`.
6. Subscribe to `subscription.activated`, `subscription.charged`, `subscription.cancelled`, `subscription.halted`, and `subscription.completed` events.
7. Copy the webhook secret to `RAZORPAY_WEBHOOK_SECRET`.
8. Test checkout and webhook in test mode before enabling live payments.

## Publish with Render (simple approach)
1. Create a GitHub repository and upload all project files except `.env`, `node_modules`, `data/`, and `uploads/`.
2. In Render, create a **Web Service** and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env` in Render's Environment settings. Do not upload `.env` to GitHub.
6. Attach a persistent disk mounted at a path such as `/var/data`; set `DATABASE_PATH=/var/data/nyx.sqlite`.
7. Use a durable session store before production traffic; Express MemoryStore will lose sessions on restarts and is not intended for production.
8. Set `APP_URL` to the deployed HTTPS URL and `NODE_ENV=production`.
9. Add the final HTTPS webhook URL in Razorpay and verify it.
10. Test sign-up, sign-in, chat, web search, files, owner Premium, subscription test checkout, and video generation.

## API key and cost notes
Provider keys are read only on the server. Chat/image/video requests may incur provider charges. Do not promise unlimited usage without budgets, quotas, and abuse controls. Add a privacy policy, terms, cancellation/refund details, contact email, monitoring, and backups before inviting the public.
